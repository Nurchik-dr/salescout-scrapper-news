import eslintConfigPrettier from 'eslint-config-prettier';

export default [
    eslintConfigPrettier,
];